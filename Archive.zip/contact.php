<?php
include "header.php";
?>
</head>
<body class="loading mainContainer" id="home">
<div class="secondaryPages">
	<div class="navigation">
		<h1 class="altNav altTitle" alt="Jacob Hook" title="Jacob Hook"><a href="index.php">Jacob Hook</a></h1>
		<!--p style="color:white;font-family: 'Raleway', sans-serif;">Website Under Construction</p-->
		<div class="altNav"><a class="links" href="work.php">Work</a> | <a class="links" href="blog.php">Blog</a> | <a class="links" href="contact.php"> Contact</a></div>
	</div>
</div>
<br/>
<br/>
<p style="color:black;text-align:center;">Coming Soon.</p>
<?php
include "footer.php";
?>